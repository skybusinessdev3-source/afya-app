import json
from decimal import Decimal, InvalidOperation

from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import Q
from django.http import JsonResponse
from django.shortcuts import render
from django.utils import timezone
from django.views.decorators.http import require_POST

from apps.audit.models import AuditLog
from apps.audit.utils import log_event
from apps.core.utils import can_backdate, parse_operation_date
from apps.finance.models import Invoice, Payment
from apps.finance.views import _creance_info
from apps.patients.models import Patient
from .models import PharmacyProduct, PharmacySale, StockMovement


def get_client_ip(request):
    x_forwarded = request.META.get('HTTP_X_FORWARDED_FOR')
    return x_forwarded.split(',')[0] if x_forwarded else request.META.get('REMOTE_ADDR')


@login_required
def pharmacy_sale(request):
    today = timezone.localdate()
    sales_today = PharmacySale.objects.filter(date=today).select_related('product', 'patient')
    context = {
        'page_title': 'Pharmacie',
        'today': today,
        'can_backdate': can_backdate(request.user),
        'sales_today': sales_today,
        'sales_total_usd': sum(s.total_usd for s in sales_today),
        'sales_total_fc': sum(s.total_fc for s in sales_today),
        'count_today': sales_today.count(),
    }
    return render(request, 'pharmacy/sale.html', context)


@login_required
def product_search(request):
    q = request.GET.get('q', '').strip()
    if len(q) < 2:
        return JsonResponse({'results': []})
    products = PharmacyProduct.objects.filter(Q(name__icontains=q), is_active=True)[:8]
    results = [{
        'id': p.id,
        'name': p.name,
        'price_usd': float(p.price_usd),
        'price_fc': float(p.price_fc),
        'stock': p.stock_available,
    } for p in products]
    return JsonResponse({'results': results})


@login_required
@require_POST
@transaction.atomic
def sale_create(request):
    """
    Vente panier : plusieurs produits d'un coup.
    - 1 facture unique (total recalculé CÔTÉ SERVEUR)
    - 1 vente + 1 mouvement de stock par produit
    - paiement éventuel (devise libre)
    """
    try:
        data = json.loads(request.body)

        patient_id = data.get('patient_id')
        patient = Patient.objects.filter(pk=patient_id, is_active=True).first() if patient_id else None

        items = data.get('items', [])
        if not items:
            return JsonResponse({'success': False, 'message': "Ajoutez au moins un produit."}, status=400)

        # Date d'opération (saisie différée — réservée aux responsables)
        op_date, err = parse_operation_date(request.user, data.get('date'))
        if err:
            return JsonResponse({'success': False, 'message': err}, status=403)

        # Vérification stock + récupération produits (serveur = autorité, §11)
        lines = []
        for it in items:
            product = PharmacyProduct.objects.select_for_update().get(
                pk=it['product_id'], is_active=True)
            qty = int(it.get('quantity', 1))
            if qty <= 0:
                return JsonResponse({'success': False, 'message': f"Quantité invalide : {product.name}"}, status=400)
            if qty > product.stock_available:
                return JsonResponse({
                    'success': False,
                    'message': f"Stock insuffisant pour « {product.name} » "
                               f"(dispo: {product.stock_available}, demandé: {qty}).",
                }, status=400)
            lines.append((product, qty))

        # Total recalculé serveur
        currency = data.get('currency', 'USD')
        total_usd = sum(p.price_usd * q for p, q in lines)
        total_fc = sum(p.price_fc * q for p, q in lines)
        due = total_fc if currency == 'FC' else total_usd

        # Ventes + mouvements (créés par le modèle)
        for product, qty in lines:
            sale = PharmacySale.objects.create(
                patient=patient, product=product, quantity=qty, date=op_date,
                sold_by=request.user)
            log_event(user=request.user, action=AuditLog.Actions.CREATE,
                      module='pharmacy', obj=sale, ip_address=get_client_ip(request))

        invoice = Invoice.objects.create(
            patient=patient,
            label=f"Pharmacie — {len(lines)} article(s)",
            amount_original=due,
            currency_original=currency,
            date=op_date,
            created_by=request.user,
        )
        log_event(user=request.user, action=AuditLog.Actions.CREATE,
                  module='finance', obj=invoice, ip_address=get_client_ip(request))

        # --- Paiements éventuels — 1 ou 2 devises (paiement mixte $ + FC) ---
        cur1 = data.get('paid_currency', currency)
        paiements = [
            (Decimal(str(data.get('amount_paid', '0') or '0')), cur1),
            (Decimal(str(data.get('amount_paid2', '0') or '0')),
             data.get('paid_currency2') or ('FC' if cur1 == 'USD' else 'USD')),
        ]
        paiements = [(a, c) for a, c in paiements if a > 0]
        for amount_paid, cur in paiements:
            payment = Payment.objects.create(
                invoice=invoice,
                amount_original=amount_paid,
                currency_original=cur,
                date=op_date,
                received_by=request.user,
            )
            log_event(user=request.user, action=AuditLog.Actions.CREATE,
                      module='finance', obj=payment, ip_address=get_client_ip(request))

        return JsonResponse({
            'success': True,
            'message': f"Vente enregistrée : {len(lines)} article(s)"
                       + (f" pour {patient.full_name}" if patient else " (client comptant)"),
            'total_usd': float(total_usd),
            'total_fc': float(total_fc),
            'creance': _creance_info(invoice),
        })

    except PharmacyProduct.DoesNotExist:
        return JsonResponse({'success': False, 'message': "Produit introuvable."}, status=404)
    except (InvalidOperation, ValueError, KeyError):
        return JsonResponse({'success': False, 'message': "Données invalides."}, status=400)


@login_required
@require_POST
@transaction.atomic
def product_create(request):
    """Crée un produit + mouvement d'entrée de stock initial (tracé)."""
    try:
        data = json.loads(request.body)
        name = data.get('name', '').strip()
        price_usd = Decimal(str(data.get('price_usd', '0')))
        price_fc = Decimal(str(data.get('price_fc', '0')))
        initial_qty = int(data.get('initial_qty', 0) or 0)

        if not name or price_usd <= 0 or price_fc <= 0:
            return JsonResponse({'success': False, 'message': "Nom et prix ($ et FC) obligatoires."}, status=400)
        if PharmacyProduct.objects.filter(name__iexact=name).exists():
            return JsonResponse({'success': False, 'message': "Un produit porte déjà ce nom."}, status=400)

        product = PharmacyProduct.objects.create(
            name=name, price_usd=price_usd, price_fc=price_fc,
            expiry_date=data.get('expiry_date') or None,
            observation=data.get('observation', ''),
        )
        log_event(user=request.user, action=AuditLog.Actions.CREATE,
                  module='pharmacy', obj=product, ip_address=get_client_ip(request))

        if initial_qty > 0:
            movement = StockMovement.objects.create(
                product=product, movement_type=StockMovement.Type.IN,
                quantity=initial_qty, reason="Stock initial", created_by=request.user)
            log_event(user=request.user, action=AuditLog.Actions.CREATE,
                      module='pharmacy', obj=movement, ip_address=get_client_ip(request))

        return JsonResponse({'success': True,
                             'message': f"Produit « {product.name} » créé (stock : {product.stock_available})."})
    except (InvalidOperation, ValueError):
        return JsonResponse({'success': False, 'message': "Données invalides."}, status=400)
    
@login_required
def products_page(request):
    produits = PharmacyProduct.objects.all().order_by('name')
    data = []
    for p in produits:
        stock = p.stock_available
        if stock == 0:
            statut, couleur = 'RUPTURE', 'red'
        elif stock <= 5:
            statut, couleur = 'BAS', 'amber'
        else:
            statut, couleur = 'NORMAL', 'green'
        data.append({'p': p, 'stock': stock, 'statut': statut, 'couleur': couleur})
    return render(request, 'pharmacy/products.html', {
        'page_title': 'Stock pharmacie',
        'produits': data,
    })


@login_required
@require_POST
@transaction.atomic
def api_product_update(request, pk):
    """Modification d'un produit (prix, nom, expiration, observation)."""
    try:
        p = PharmacyProduct.objects.get(pk=pk)
        data = json.loads(request.body)
        if data.get('name', '').strip():
            p.name = data['name'].strip()
        if 'price_usd' in data:
            p.price_usd = Decimal(str(data['price_usd']))
        if 'price_fc' in data:
            p.price_fc = Decimal(str(data['price_fc']))
        if 'expiry_date' in data:
            p.expiry_date = data['expiry_date'] or None
        p.observation = data.get('observation', p.observation)
        p.save()
        log_event(user=request.user, action=AuditLog.Actions.UPDATE,
                  module='pharmacy', obj=p, ip_address=get_client_ip(request))
        return JsonResponse({'success': True, 'message': f"« {p.name} » mis à jour."})
    except (PharmacyProduct.DoesNotExist, InvalidOperation, ValueError):
        return JsonResponse({'success': False, 'message': 'Données invalides.'}, status=400)


@login_required
@require_POST
@transaction.atomic
def api_stock_add(request, pk):
    """Réapprovisionnement : nouvelle ENTRÉE de stock tracée (§11)."""
    try:
        p = PharmacyProduct.objects.get(pk=pk, is_active=True)
        data = json.loads(request.body)
        qty = int(data.get('quantity', 0))
        if qty <= 0:
            return JsonResponse({'success': False, 'message': 'Quantité invalide.'}, status=400)
        movement = StockMovement.objects.create(
            product=p,
            movement_type=StockMovement.Type.IN,
            quantity=qty,
            reason=data.get('reason', 'Réapprovisionnement'),
            created_by=request.user,
        )
        log_event(user=request.user, action=AuditLog.Actions.CREATE,
                  module='pharmacy', obj=movement, ip_address=get_client_ip(request))
        return JsonResponse({'success': True,
                             'message': f"+{qty} « {p.name} » — stock actuel : {p.stock_available}."})
    except (PharmacyProduct.DoesNotExist, ValueError):
        return JsonResponse({'success': False, 'message': 'Données invalides.'}, status=400)


@login_required
@require_POST
@transaction.atomic
def api_product_toggle(request, pk):
    p = PharmacyProduct.objects.get(pk=pk)
    p.is_active = not p.is_active
    p.save(update_fields=['is_active'])
    return JsonResponse({'success': True,
                         'message': f"« {p.name} » : {'activé' if p.is_active else 'désactivé'}."})