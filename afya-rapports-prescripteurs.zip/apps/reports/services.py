from collections import defaultdict
from datetime import date as date_cls
from decimal import Decimal, ROUND_HALF_UP

from django.db.models import Sum

from apps.appointments.models import Appointment
from apps.centre.models import Session
from apps.finance.models import Expense, Payment
from apps.laboratory.models import LaboratoryRecord
from apps.home_care.models import HomeCareService
from apps.medicine.models import MedicineRecord
from apps.pharmacy.models import PharmacySale


# ================= OUTILS =================

def _sums_by_currency(queryset):
    """Jamais mélanger les devises : {'USD': x, 'FC': y}"""
    usd = queryset.filter(currency_original='USD').aggregate(t=Sum('amount_original'))['t'] or 0
    fc = queryset.filter(currency_original='FC').aggregate(t=Sum('amount_original'))['t'] or 0
    return {'USD': usd, 'FC': fc}


def _fmt(amounts):
    parts = []
    if amounts['USD']:
        parts.append(f"{amounts['USD']}$")
    if amounts['FC']:
        parts.append(f"{amounts['FC']:,.0f}fc".replace(',', ' '))
    return ' + '.join(parts) if parts else '0'


def _categorize(payment):
    inv = payment.invoice
    if inv is None:
        return 'centre'
    if inv.lab_records.exists():
        return 'laboratoire'
    if inv.home_care_services.exists():
        return 'domicile'
    if inv.label.startswith('Pharmacie'):
        return 'pharmacie'
    med = inv.medicine_records.first()
    if med is not None:
        return 'medecine_manuelle' if med.category.startswith('MANUAL') else 'medecine_generale'
    return 'centre'


def _ventilation(payments):
    vent = defaultdict(lambda: {'USD': 0, 'FC': 0})
    for p in payments.select_related('invoice'):
        vent[_categorize(p)][p.currency_original] += p.amount_original
    return vent


# ================= AVANCES SÉANCES =================
# (x/y) dans le rapport = x séances EFFECTUÉES / y séances PAYÉES (avance),
# et non « y prescrites » : tout le monde ne paie pas de la même manière.
# prix_séance = montant dû (centre) ÷ séances prescrites → y = payé ÷ prix_séance.

def _factures_centre(patient_ids):
    """Montants dus/payés (USD) des factures 'centre' de chaque patient :
    on exclut pharmacie, labo, médecine et soins à domicile — seules les
    séances/consultations comptent pour l'avance en séances."""
    from apps.finance.models import Invoice, Payment
    res = {pid: {'due': Decimal('0'), 'paid': Decimal('0')} for pid in patient_ids}
    if not patient_ids:
        return res
    invoices = (Invoice.objects
                .filter(patient_id__in=patient_ids)
                .exclude(status=Invoice.Status.CANCELLED)
                .prefetch_related('lab_records', 'home_care_services',
                                  'medicine_records', 'payments'))
    for inv in invoices:
        if (inv.label.startswith('Pharmacie') or inv.lab_records.exists()
                or inv.home_care_services.exists() or inv.medicine_records.exists()):
            continue  # pas une facture de séances/consultations
        res[inv.patient_id]['due'] += inv.amount_usd
        res[inv.patient_id]['paid'] += sum(
            p.amount_usd for p in inv.payments.all()
            if p.status == Payment.Status.VALID)
    return res


def _seances_payees(due, paid, prescribed):
    """Nombre de séances payées (avance). None si non calculable
    (pas de séances prescrites ou pas de montant dû au centre)."""
    if not prescribed or prescribed <= 0 or due <= 0:
        return None
    prix = due / prescribed
    if prix <= 0:
        return None
    return (paid / prix).quantize(Decimal('0.1'), rounding=ROUND_HALF_UP)


def _fmt_seances(nb):
    """3.0 → '3' ; 2.5 → '2.5'."""
    if nb is None:
        return None
    return _fmt_nombre(nb)


def _fmt_nombre(d):
    """Decimal → texte lisible : 20 (jamais '2E+1'), 12.5 (jamais '12.50')."""
    txt = format(d, 'f')
    if '.' in txt:
        txt = txt.rstrip('0').rstrip('.')
    return txt


# ================= JOURNALIER =================

def daily_report(d):
    sessions = Session.objects.filter(date=d).select_related('patient', 'patient__company', 'service')
    payments = Payment.objects.filter(date=d, status=Payment.Status.VALID)
    expenses = Expense.objects.filter(date=d)

    vent = _ventilation(payments)
    # Avances : factures 'centre' de tous les patients présents ce jour
    pids = {s.patient_id for s in sessions}
    fin = _factures_centre(pids)

    # Produits achetés en pharmacie ce jour, regroupés par patient
    ventes_jour = list(PharmacySale.objects.filter(date=d).select_related('product', 'patient'))
    produits = {}
    for v in ventes_jour:
        if v.patient_id and v.product_id:
            produits.setdefault(v.patient_id, []).append(v)

    def _produits_label(patient_id):
        # '3 Navrox + 2 Orthoglic + Baume' - quantité affichée seulement si > 1
        achats = produits.get(patient_id)
        if not achats:
            return ""
        return " + ".join(
            f"{v.quantity} {v.product.name}" if v.quantity > 1 else v.product.name
            for v in achats)

    def _seances_label(session):
        patient = session.patient
        # Patient d'une ENTREPRISE (LTJ, GGA…) — tout sauf « Privée » :
        # c'est l'entreprise qui paie → on affiche son NOM, pas un compteur.
        if (patient.company_id and patient.company
                and patient.company.name.strip().lower() not in ('privée', 'privee')):
            return f"_{patient.company.name}_"
        # Pas une séance de kiné (évaluation, labo, consultation…) :
        # on affiche le MOTIF, jamais un compteur de séances « 1/0 ».
        if session.motif != Session.Motif.KINE:
            return f"_{session.get_motif_display()}_"
        payees = _seances_payees(fin[patient.id]['due'], fin[patient.id]['paid'],
                                 patient.sessions_prescribed)
        total = _fmt_seances(payees)
        if total is None:                       # pas de tarif calculable → prescrites
            total = patient.sessions_prescribed
        if not total:                           # aucune prescription → texte, pas « 1/0 »
            return f"_{session.get_motif_display()}_"
        return f"_{patient.sessions_done}/{total}_"

    patients_lines = []
    for i, s in enumerate(sessions, 1):
        pays = [p for p in payments if p.invoice and p.invoice.patient_id == s.patient_id]
        amounts = {'USD': sum(p.amount_original for p in pays if p.currency_original == 'USD'),
                   'FC': sum(p.amount_original for p in pays if p.currency_original == 'FC')}
        money = f" : {_fmt(amounts)}" if (amounts['USD'] or amounts['FC']) else ""
        seances = _seances_label(s)
        prods = _produits_label(s.patient_id)
        detail = f" ; {prods}" if prods else ""
        patients_lines.append(f"{i}. {s.patient.full_name} ({seances}{money}{detail})")

    # --- Patients des AUTRES services (labo, médecine, domicile, pharmacie) ---
    # Pas de séance au centre ce jour → ils doivent quand même apparaître au rapport.
    seen = {s.patient_id for s in sessions}
    extra = {}

    def _add_extra(patient, tag):
        if patient is None or patient.id in seen:
            return
        extra.setdefault(patient.id, {'patient': patient, 'tags': set()})['tags'].add(tag)

    for r in LaboratoryRecord.objects.filter(date=d).select_related('patient'):
        _add_extra(r.patient, 'Labo')
    for r in MedicineRecord.objects.filter(date=d).select_related('patient'):
        _add_extra(r.patient, 'Médecine')
    for r in HomeCareService.objects.filter(date=d).select_related('patient'):
        _add_extra(r.patient, 'Domicile')
    for s in PharmacySale.objects.filter(date=d).select_related('patient'):
        _add_extra(s.patient, 'Pharmacie')

    i = len(patients_lines)
    for pid, info in extra.items():
        pays = [p for p in payments if p.invoice and p.invoice.patient_id == pid]
        amounts = {'USD': sum(p.amount_original for p in pays if p.currency_original == 'USD'),
                   'FC': sum(p.amount_original for p in pays if p.currency_original == 'FC')}
        money = f" : {_fmt(amounts)}" if (amounts['USD'] or amounts['FC']) else ""
        prods = _produits_label(pid)
        detail = f" : {prods}" if prods else ""
        i += 1
        patients_lines.append(f"{i}. {info['patient'].full_name} "
                              f"({'/'.join(sorted(info['tags']))}{money}{detail})")

    exp_total = _sums_by_currency(expenses)
    total = _sums_by_currency(payments)

    return {
        'label': d.strftime('%d/%m/%Y'),
        'patients_count': len(seen) + len(extra),
        'sessions_count': sessions.count(),
        'patients_lines': patients_lines,
        'pharmacy': _fmt(vent['pharmacie']),
        'laboratory': _fmt(vent['laboratoire']),
        'home_care': _fmt(vent['domicile']),
        'centre': _fmt(vent['centre']),
        'med_gen': _fmt(vent['medecine_generale']),
        'med_man': _fmt(vent['medecine_manuelle']),
        'total_percus': _fmt(total),
        'expense_lines': [f"* {e.label} : _{e.amount_original} {e.currency_original}_" for e in expenses],
        'total_depenses': _fmt(exp_total),
        'solde': _fmt({'USD': total['USD'] - exp_total['USD'], 'FC': total['FC'] - exp_total['FC']}),
        'extra': f"Pharmacie : {len(ventes_jour)} vente(s) · "
                 f"Labo : {LaboratoryRecord.objects.filter(date=d).count()} examen(s)",
    }


def whatsapp_daily(r):
    lines = [
        f"*RAPPORT DU {r['label']}*", "",
        "Bonsoir à tous,", "",
        "J'espère que vous vous portez bien. C'est avec plaisir que je vous présente le rapport d'activités du jour.", "",
        f"Le CRF-MK a fonctionné normalement aujourd'hui en enregistrant {r['patients_count']} patients.", "",
        "*LISTE DES PATIENTS ET MOUVEMENTS :*",
        *(r['patients_lines'] or ["—"]), "",
        "*VENTILATION DES RECETTES :*",
        f"*CENTRE (séances/consultations)* : _{r['centre']}_",
        f"*MÉDECINE GÉNÉRALE* : _{r['med_gen']}_",
        f"*MÉDECINE MANUELLE* : _{r['med_man']}_",
        f"*PHARMACIE* : _{r['pharmacy']}_",
        f"*LABORATOIRE* : _{r['laboratory']}_",
        f"*SOINS À DOMICILE* : _{r['home_care']}_",
        f"*TOTAL PERÇUS* : _{r['total_percus']}_", "",
        "*DÉPENSES DU JOUR :*",
        *(r['expense_lines'] or ["—"]),
        f"*Total Dépenses :* _{r['total_depenses']}_", "",
        "*SOLDE / RESTE EN MAIN :*",
        f"_{r['solde']}_", "",
        "*Cordialement* 🙌",
    ]
    return '\n'.join(lines)


# ================= MENSUEL =================

def monthly_report(year, month):
    payments = Payment.objects.filter(date__year=year, date__month=month, status='VALID')
    expenses = Expense.objects.filter(date__year=year, date__month=month)
    sessions = Session.objects.filter(date__year=year, date__month=month)

    vent = _ventilation(payments)
    exp_total = _sums_by_currency(expenses)
    total = _sums_by_currency(payments)
    from django.utils import timezone
    import calendar
    month_name = calendar.month_name[month] if hasattr(calendar, 'month_name') else str(month)
    # noms français :
    MOIS = ['', 'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet',
            'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre']

    return {
        'label': f"{MOIS[month]} {year}",
        'patients_count': sessions.values('patient').distinct().count(),
        'sessions_count': sessions.count(),
        'jours_actifs': sessions.values('date').distinct().count(),
        'pharmacy': _fmt(vent['pharmacie']),
        'laboratory': _fmt(vent['laboratoire']),
        'home_care': _fmt(vent['domicile']),
        'centre': _fmt(vent['centre']),
        'med_gen': _fmt(vent['medecine_generale']),
        'med_man': _fmt(vent['medecine_manuelle']),
        'total_percus': _fmt(total),
        'med_gen_count': MedicineRecord.objects.filter(
            date__year=year, date__month=month).exclude(category__startswith='MANUAL').count(),
        'med_man_count': MedicineRecord.objects.filter(
            date__year=year, date__month=month, category__startswith='MANUAL').count(),
        'expenses_count': expenses.count(),
        'total_depenses': _fmt(exp_total),
        'solde': _fmt({'USD': total['USD'] - exp_total['USD'], 'FC': total['FC'] - exp_total['FC']}),
        'lab_count': LaboratoryRecord.objects.filter(date__year=year, date__month=month).count(),
        'sales_count': PharmacySale.objects.filter(date__year=year, date__month=month).count(),
        'home_care_count': HomeCareService.objects.filter(date__year=year, date__month=month).count(),
    }


def whatsapp_monthly(r):
    lines = [
        f"*RAPPORT MENSUEL — {r['label']}*", "",
        "Bonsoir à tous,", "",
        "Voici le bilan du mois.", "",
        f"*ACTIVITÉ* : {r['patients_count']} patients · {r['sessions_count']} séances · {r['jours_actifs']} jours d'activité", "",
        "*VENTILATION DES RECETTES :*",
        f"*CENTRE (séances/consultations)* : _{r['centre']}_",
        f"*MÉDECINE GÉNÉRALE* : _{r['med_gen']}_ ({r['med_gen_count']} actes)",
        f"*MÉDECINE MANUELLE* : _{r['med_man']}_ ({r['med_man_count']} actes)",
        f"*PHARMACIE* : _{r['pharmacy']}_ ({r['sales_count']} ventes)",
        f"*LABORATOIRE* : _{r['laboratory']}_ ({r['lab_count']} examens)",
        f"*SOINS À DOMICILE* : _{r['home_care']}_ ({r['home_care_count']} prestations)",
        f"*TOTAL PERÇUS* : _{r['total_percus']}_", "",
        f"*DÉPENSES ({r['expenses_count']})* : _{r['total_depenses']}_", "",
        "*SOLDE NET DU MOIS :*",
        f"_{r['solde']}_", "",
        "*Cordialement* 🙌",
    ]
    return '\n'.join(lines)


# ================= ANNUEL =================

def annual_report(year):
    MOIS = ['', 'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet',
            'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre']
    months = []
    tot_percus = {'USD': 0, 'FC': 0}
    tot_dep = {'USD': 0, 'FC': 0}
    tot_patients = 0

    for m in range(1, 13):
        payments = Payment.objects.filter(date__year=year, date__month=m, status='VALID')
        expenses = Expense.objects.filter(date__year=year, date__month=m)
        sessions = Session.objects.filter(date__year=year, date__month=m)
        per = _sums_by_currency(payments)
        dep = _sums_by_currency(expenses)
        patients = sessions.values('patient').distinct().count()
        tot_percus['USD'] += per['USD']; tot_percus['FC'] += per['FC']
        tot_dep['USD'] += dep['USD']; tot_dep['FC'] += dep['FC']
        tot_patients += patients
        months.append({
            'num': m, 'name': MOIS[m],
            'patients': patients, 'sessions': sessions.count(),
            'percus': _fmt(per), 'depenses': _fmt(dep),
            'percus_usd': float(per['USD']), 'percus_fc': float(per['FC']),
        })

    return {
        'label': str(year),
        'months': months,
        'patients_total': tot_patients,
        'total_percus': _fmt(tot_percus),
        'total_depenses': _fmt(tot_dep),
        'solde': _fmt({'USD': tot_percus['USD'] - tot_dep['USD'],
                       'FC': tot_percus['FC'] - tot_dep['FC']}),
    }


def whatsapp_annual(r):
    lines = [
        f"*RAPPORT ANNUEL — {r['label']}*", "",
        "Bonsoir à tous,", "",
        f"Bilan de l'année : {r['patients_total']} passages patients au total.", "",
        "*TOTAL PERÇUS* : _" + r['total_percus'] + "_",
        "*TOTAL DÉPENSES* : _" + r['total_depenses'] + "_", "",
        "*SOLDE NET DE L'ANNÉE :*",
        f"_{r['solde']}_", "",
        "*Cordialement* 🙌",
    ]
    return '\n'.join(lines)

# ================= ENTREPRISES (ex : LTJ) =================
# Les impayés des patients d'une entreprise « facturée à l'entreprise » ne sont
# PAS des dettes patient : ce sont des CRÉANCES sur l'entreprise, récapitulées
# ici mensuellement (format de l'annexe LTJ).

PRIX_SEANCE_DEFAUT = Decimal('20')   # tarif général d'une séance kiné


def _prix_seance(patient):
    """Prix d'une séance pour ce patient : montant dû (centre) ÷ prescrites,
    sinon tarif général (20 $)."""
    fin = _factures_centre([patient.id])[patient.id]
    if patient.sessions_prescribed > 0 and fin['due'] > 0:
        prix = (fin['due'] / patient.sessions_prescribed).quantize(
            Decimal('0.01'), rounding=ROUND_HALF_UP)
        if prix > 0:
            return prix
    return PRIX_SEANCE_DEFAUT


def company_report(company, year, month):
    """Rapport mensuel des patients d'une entreprise (créances entreprise)."""
    import calendar as _cal
    from apps.finance.models import Invoice, Payment

    MOIS = ['', 'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet',
            'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre']
    last_day = _cal.monthrange(year, month)[1]

    rows = []
    tot = {'pharmacie': Decimal('0'), 'prescrit': 0, 'effectue': 0,
           'restant': 0, 'cout': Decimal('0')}

    for p in company.patients.all():
        sessions_m = p.sessions.filter(date__year=year, date__month=month,
                                       status='DONE').order_by('date')
        invoices = [i for i in p.invoices
                    .filter(date__year=year, date__month=month)
                    .exclude(status=Invoice.Status.CANCELLED)
                    .prefetch_related('lab_records', 'home_care_services',
                                      'medicine_records')]
        if not sessions_m.exists() and not invoices:
            continue  # aucune activité ce mois → hors rapport

        # « Pharmacie & Autres » = facturé hors séances (pharmacie, labo,
        # médecine, domicile) — la créance naît à la FACTURATION (pas au paiement)
        pharmacie = Decimal('0')
        for inv in invoices:
            if (inv.label.startswith('Pharmacie') or inv.lab_records.exists()
                    or inv.home_care_services.exists() or inv.medicine_records.exists()):
                pharmacie += inv.amount_usd

        effectue = sessions_m.count()
        prescrit = p.sessions_prescribed
        restant = max(prescrit - effectue, 0)
        prix = _prix_seance(p)
        cout = (prix * effectue).quantize(Decimal('0.01'))

        # Colonne Date : plage des séances du mois (« 01-30/07/2026 »)
        if sessions_m.exists():
            d1, d2 = sessions_m.first().date, sessions_m.last().date
            date_txt = (f"{d1:%d/%m/%Y}" if d1 == d2
                        else f"{d1:%d}-{d2:%d/%m/%Y}")
        elif invoices:
            date_txt = f"{min(i.date for i in invoices):%d/%m/%Y}"
        else:
            date_txt = '—'

        obs = []
        obs.append("Séances en cours" if restant > 0 else "Séances terminées")
        if pharmacie > 0:
            obs.append("Pharmacie")

        rows.append({
            'patient': p, 'pharmacie': pharmacie, 'prescrit': prescrit,
            'effectue': effectue, 'restant': restant, 'prix': prix,
            'cout': cout, 'cout_txt': f"{_fmt_nombre(prix)}x{effectue}={_fmt_nombre(cout)}",
            'date_txt': date_txt, 'observation': ' + '.join(obs),
        })
        tot['pharmacie'] += pharmacie
        tot['prescrit'] += prescrit
        tot['effectue'] += effectue
        tot['restant'] += restant
        tot['cout'] += cout

    return {
        'company': company,
        'label': f"{MOIS[month]} {year}",
        'mois_nom': MOIS[month].upper(),
        'year': year, 'month': month,
        'rows': rows,
        'tot': tot,
        'total_general': tot['pharmacie'] + tot['cout'],
        'cloture': f"CLOTURE {last_day:02d}/{month:02d}/{year}",
        'creance_usd': sum(
            i.balance_usd for i in Invoice.objects
            .filter(patient__company=company)
            .exclude(status=Invoice.Status.CANCELLED)
            .prefetch_related('payments')
            if i.balance_usd > 0),
    }


# ================= PRESCRIPTEURS & ACTIVITÉS =================

NON_RENSEIGNE = '— Non renseigné —'

# Onglets du rapport par activité : (slug, libellé court)
ACTIVITES = [
    ('centre', 'Centre'),
    ('medecine-generale', 'Méd. générale'),
    ('medecine-manuelle', 'Méd. manuelle'),
    ('pharmacie', 'Pharmacie'),
    ('labo', 'Laboratoire'),
    ('domicile', 'Domicile'),
]


def _norm_prescriber_name(name):
    """Normalise un nom de prescripteur pour le regroupement :
    strip, espaces multiples → 1, casse-insensible.
    (« / » → espace : la clé transite dans l'URL.)"""
    if not name:
        return ''
    return ' '.join(str(name).replace('/', ' ').split()).lower()


def _prescriber_display(record):
    """Nom affiché : prescriber_name libre, sinon FK Staff, sinon placeholder."""
    name = getattr(record, 'prescriber_name', '') or ''
    if name.strip():
        return ' '.join(name.split())
    prescriber = getattr(record, 'prescriber', None)
    if prescriber is not None:
        return str(prescriber)
    return NON_RENSEIGNE


def _med_family(category):
    """GENERAL_* → 'generale', MANUAL* → 'manuelle'."""
    return 'manuelle' if (category or '').startswith('MANUAL') else 'generale'


def _med_detail(record):
    """Prestation affichée : catégorie + précision éventuelle."""
    label = record.get_category_display()
    if record.prestation_other:
        label += f" — {record.prestation_other}"
    return label


def _date_txt(d):
    return f"{d:%d/%m/%Y}"


def prescribers_summary(d1, d2):
    """Liste des prescripteurs (labo + médecine) ayant des actes entre d1 et d2
    inclus, regroupés par nom normalisé, triés par nom."""
    summary = {}

    def _touch(record, kind):
        name = _prescriber_display(record)
        key = _norm_prescriber_name(name)
        entry = summary.setdefault(key, {
            'key': key, 'name': name,
            'labo_count': 0, 'labo_share': Decimal('0'),
            'med_count': 0, 'med_share': Decimal('0'),
        })
        entry[f'{kind}_count'] += 1
        entry[f'{kind}_share'] += record.prescriber_amount_usd or Decimal('0')

    for r in (LaboratoryRecord.objects
              .filter(date__gte=d1, date__lte=d2)
              .select_related('prescriber')):
        _touch(r, 'labo')
    for r in MedicineRecord.objects.filter(date__gte=d1, date__lte=d2):
        _touch(r, 'med')

    rows = sorted(summary.values(), key=lambda e: e['name'].casefold())
    for e in rows:
        e['total_share'] = e['labo_share'] + e['med_share']
        e['labo_share_txt'] = _fmt_nombre(e['labo_share'])
        e['med_share_txt'] = _fmt_nombre(e['med_share'])
        e['total_share_txt'] = _fmt_nombre(e['total_share'])
    return rows


def prescriber_report(key, d1, d2):
    """Rapport individuel d'un prescripteur : tous ses actes (labo + médecine)
    entre d1 et d2, triés par date."""
    key_norm = _norm_prescriber_name(key)
    rows = []
    display_name = None

    for r in (LaboratoryRecord.objects
              .filter(date__gte=d1, date__lte=d2)
              .select_related('prescriber', 'patient', 'exam')):
        name = _prescriber_display(r)
        if _norm_prescriber_name(name) != key_norm:
            continue
        display_name = display_name or name
        rows.append({
            'date': r.date, 'date_txt': _date_txt(r.date),
            'activite': 'Labo',
            'patient': r.patient.full_name,
            'detail': r.exam.name,
            'montant_usd': r.amount_usd,
            'part_usd': r.prescriber_amount_usd,
            'montant_txt': _fmt_nombre(r.amount_usd),
            'part_txt': _fmt_nombre(r.prescriber_amount_usd),
            'observation': r.observation or '',
        })

    for r in (MedicineRecord.objects
              .filter(date__gte=d1, date__lte=d2)
              .select_related('patient')):
        name = _prescriber_display(r)
        if _norm_prescriber_name(name) != key_norm:
            continue
        display_name = display_name or name
        rows.append({
            'date': r.date, 'date_txt': _date_txt(r.date),
            'activite': 'Méd. manuelle' if _med_family(r.category) == 'manuelle' else 'Méd. générale',
            'patient': r.patient.full_name,
            'detail': _med_detail(r),
            'montant_usd': r.amount_usd,
            'part_usd': r.prescriber_amount_usd,
            'montant_txt': _fmt_nombre(r.amount_usd),
            'part_txt': _fmt_nombre(r.prescriber_amount_usd),
            'observation': r.observation or '',
        })

    rows.sort(key=lambda x: (x['date'], x['activite'], x['patient']))
    total_billed = sum((x['montant_usd'] for x in rows), Decimal('0'))
    total_share = sum((x['part_usd'] for x in rows), Decimal('0'))

    return {
        'name': display_name or key,
        'd1': d1, 'd2': d2,
        'periode_txt': f"du {_date_txt(d1)} au {_date_txt(d2)}",
        'rows': rows,
        'total_billed': total_billed,
        'total_share': total_share,
        'total_billed_txt': _fmt_nombre(total_billed),
        'total_share_txt': _fmt_nombre(total_share),
    }


def _factures_centre_par_jour(patient_ids, d1, d2):
    """(patient_id, date) → montant USD des factures 'centre' du jour
    (on exclut pharmacie, labo, médecine, domicile et les annulées)."""
    from apps.finance.models import Invoice
    res = defaultdict(lambda: Decimal('0'))
    if not patient_ids:
        return res
    invoices = (Invoice.objects
                .filter(patient_id__in=patient_ids, date__gte=d1, date__lte=d2)
                .exclude(status=Invoice.Status.CANCELLED)
                .prefetch_related('lab_records', 'home_care_services', 'medicine_records'))
    for inv in invoices:
        if (inv.label.startswith('Pharmacie') or inv.lab_records.exists()
                or inv.home_care_services.exists() or inv.medicine_records.exists()):
            continue
        res[(inv.patient_id, inv.date)] += inv.amount_usd
    return res


def _activity_result(slug, titre, d1, d2, columns, rows, total_usd, total_qty=None):
    """Assemble le dict prêt pour template et exports."""
    total_txt = _fmt_nombre(total_usd)
    total_row = ['TOTAL'] + [''] * (len(columns) - 2) + [total_txt]
    if total_qty is not None:
        # pharmacie : quantité sous la colonne « Quantité » (4e), total en dernière
        total_row = ['TOTAL', '', '', str(total_qty), '', total_txt]
    return {
        'slug': slug, 'titre': titre,
        'd1': d1, 'd2': d2,
        'periode_txt': f"du {_date_txt(d1)} au {_date_txt(d2)}",
        'columns': columns,
        'rows': rows,
        'total_row': total_row,
        'total_usd': total_usd,
        'total_usd_txt': total_txt,
        'total_qty': total_qty,
    }


def activity_report(slug, d1, d2):
    """Rapport détaillé d'une activité entre d1 et d2 (inclus).
    Retourne None si le slug est inconnu."""
    if slug == 'centre':
        sessions = list(Session.objects
                        .filter(date__gte=d1, date__lte=d2)
                        .select_related('patient', 'service')
                        .order_by('date', 'patient__last_name'))
        factures = _factures_centre_par_jour({s.patient_id for s in sessions}, d1, d2)
        columns = ['Date', 'Patient', 'Motif / Service', 'Montant ($)']
        rows = []
        total = Decimal('0')
        for s in sessions:
            montant = factures.get((s.patient_id, s.date), Decimal('0'))
            if not montant and s.service_id:
                montant = s.service.price_usd or Decimal('0')
            detail = s.get_motif_display()
            if s.service_id:
                detail += f" ({s.service.name})"
            if s.motif == Session.Motif.OTHER and s.motif_other:
                detail += f" — {s.motif_other}"
            total += montant
            rows.append([_date_txt(s.date), s.patient.full_name, detail,
                         _fmt_nombre(montant) if montant else '—'])
        return _activity_result(slug, 'RAPPORT CENTRE — SÉANCES & CONSULTATIONS',
                                d1, d2, columns, rows, total)

    if slug == 'pharmacie':
        ventes = (PharmacySale.objects
                  .filter(date__gte=d1, date__lte=d2)
                  .select_related('product', 'patient')
                  .order_by('date', 'id'))
        columns = ['Date', 'Patient', 'Produit', 'Quantité', 'Prix unit. ($)', 'Total ($)']
        rows = []
        total = Decimal('0')
        total_qty = 0
        for v in ventes:
            total += v.total_usd
            total_qty += v.quantity
            rows.append([_date_txt(v.date),
                         v.patient.full_name if v.patient else 'Client comptant',
                         v.product.name, str(v.quantity),
                         _fmt_nombre(v.unit_price_usd), _fmt_nombre(v.total_usd)])
        return _activity_result(slug, 'RAPPORT PHARMACIE — VENTES',
                                d1, d2, columns, rows, total, total_qty=total_qty)

    if slug == 'labo':
        records = (LaboratoryRecord.objects
                   .filter(date__gte=d1, date__lte=d2)
                   .select_related('patient', 'exam', 'prescriber')
                   .order_by('date', 'id'))
        columns = ['Date', 'Patient', 'Examen', 'Prescripteur', 'Montant ($)', 'Statut']
        rows = []
        total = Decimal('0')
        for r in records:
            total += r.amount_usd
            rows.append([_date_txt(r.date), r.patient.full_name, r.exam.name,
                         _prescriber_display(r), _fmt_nombre(r.amount_usd),
                         r.get_status_display()])
        return _activity_result(slug, 'RAPPORT LABORATOIRE — EXAMENS',
                                d1, d2, columns, rows, total)

    if slug in ('medecine-generale', 'medecine-manuelle'):
        famille = 'manuelle' if slug == 'medecine-manuelle' else 'generale'
        records = [r for r in (MedicineRecord.objects
                               .filter(date__gte=d1, date__lte=d2)
                               .select_related('patient')
                               .order_by('date', 'id'))
                   if _med_family(r.category) == famille]
        columns = ['Date', 'Patient', 'Prestation', 'Prescripteur', 'Montant ($)']
        rows = []
        total = Decimal('0')
        for r in records:
            total += r.amount_usd
            rows.append([_date_txt(r.date), r.patient.full_name, _med_detail(r),
                         _prescriber_display(r), _fmt_nombre(r.amount_usd)])
        titre = ('RAPPORT MÉDECINE MANUELLE' if famille == 'manuelle'
                 else 'RAPPORT MÉDECINE GÉNÉRALE')
        return _activity_result(slug, titre, d1, d2, columns, rows, total)

    if slug == 'domicile':
        services_qs = (HomeCareService.objects
                       .filter(date__gte=d1, date__lte=d2)
                       .select_related('patient', 'doctor', 'invoice')
                       .order_by('date', 'id'))
        columns = ['Date', 'Patient', 'Prestation', 'Médecin', 'Montant ($)']
        rows = []
        total = Decimal('0')
        for s in services_qs:
            montant = (s.invoice.amount_usd
                       if s.invoice_id and s.invoice.status != 'CANCELLED' else None)
            if montant:
                total += montant
            prestation = (f"Soins à domicile — {s.sessions_done}/{s.sessions_prescribed} "
                          f"séance(s)")
            rows.append([_date_txt(s.date), s.patient.full_name, prestation,
                         str(s.doctor) if s.doctor_id else '—',
                         _fmt_nombre(montant) if montant else '—'])
        return _activity_result(slug, 'RAPPORT SOINS À DOMICILE',
                                d1, d2, columns, rows, total)

    return None
